#!/bin/bash
#
##!/usr/bin/sh     #  Declares a Bourne shell
##!/usr/bin/bash   #  Declares a Bourne-Again shell
##!/usr/bin/csh    #  Declares a C shell
##!/usr/bin/tsh    #  Declares a T shell
#
#
# SCRIPT: plan.sh
# AUTHOR: Daniel Murray
# DATE:   9/23/2016
# REV:    1.0.A (Valid are A, B, D, T and P)
#               (For Alpha, Beta, Dev, Test and Production)
#
# PLATFORM: RHEL
#
# PURPOSE: Runs terraform plan for current terraform.
#
# REVISED LIST:
#        DATE: 02/01/2017
#        BY: Jerome Gudknecht
#        MODIFICATION: Level set validate and plan steps.
#
# set -n   # Uncomment to check your syntax, without execution.
#          # NOTE: Do not forget to put the comment back in or
#          #       the shell script will not execute!
# set -x   # Uncomment to debug this shell script
#
#####################################################################

# The Environment variable will be pulled from the Jenkins parameter
# for the job once we place it into Jenkins.
# The environment variable should be lowercase.
# It is assumed that terraform is installed in /opt/terraform/terraform.
# It should have execute access for the jenkins user primarily.
if (( "$#" != 2 ))
then
    echo "Necessary to have 2 parameters."
    echo "Param 1:  Environment - Possible Values are"
    echo "Param 2:  Application Name Usage Info:…"
exit 1
fi

ENV=$(echo "$1" | tr '[:upper:]' '[:lower:]')
APPNAME=$2
. ../env_setup.sh

TF_PATH=/usr/local/bin

# Defines whether we are working with the Hosts or IAM roles or
# Security Groups.  This relates to the directory structure.

MODULE_TYPE=hosts

SUB_MODULE_TYPE=linux-web-rhel7
# Assigns local variable ENV to the JENKINS Environment Variable.



# Create the db config.  For now, we will need to modify the
# STATE_FILE parameter for each portion of the stack.
# TODO: We will owrk on parameterizing this shortly.

STATE_FILE="applications/cfg.${APPNAME}/$MODULE_TYPE/$SUB_MODULE_TYPE/terraform.tfstate"
BUCKET=tf-state-$ENV

cd ../../$MODULE_TYPE/$SUB_MODULE_TYPE/$ENV-us-east-1/
echo `pwd`
$TF_PATH/terraform remote config  -backend=S3 \
-backend-config="region=us-east-1" \
-backend-config="bucket=${BUCKET}" \
-backend-config="key=${STATE_FILE}"

# Gets the module definitions from github.
# These are not pulled via jenkins but rather by terraform itself.
# Need to go up two levels to call the main.tf

echo "Get the reference modules with the latest updated references"

$TF_PATH/terraform get -update ../

# Next perform a validate to insure the code will run.
# If not, exit out and fail the job.
echo "Starting to validate the terraform plan"
$TF_PATH/terraform remote pull
$TF_PATH/terraform validate ../

echo "Generate the plan on what will be done during this terraform run"
$TF_PATH/terraform plan ../
