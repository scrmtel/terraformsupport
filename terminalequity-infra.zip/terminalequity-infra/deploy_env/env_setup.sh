export https_proxy='http://aws_proxy_prod:A!wsp123@proxy.glic.com:8080/'
export http_proxy='http://aws_proxy_prod:A!wsp123@proxy.glic.com:8080/'
export no_proxy=localhost,localaddress,127.0.0.1,169.254.169.254,glic.com


