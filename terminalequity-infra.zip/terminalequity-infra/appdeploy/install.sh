#!/bin/sh
#------------------------------------------------------------------------------
#FILE:install.sh
#DESCRIPTION: deploy zip file 

#download file from artifactory 
source ~/.bashrc
version=REPLACE
TIMESTAMP=`date "+%Y-%m-%d %H:%M:%S"`
LOGFILE="/var/log/awscodedeploy.log"
echo "$TIMESTAMP: Starting to execute codedeploy file" >> $LOGFILE
cd /tmp 
pwd
if [ -f /tmp/TERMINALEQUITY.war ]; then
   
	rm -rf /tmp/TERMINALEQUITY.war
	echo "$TIMESTAMP: removed terminalequity.war successfully" >> $LOGFILE
fi

wget  "https://packagerepo.prod.aws.glic.com/artifactory/glic-releases-env/terminalequity-$version/TERMINALEQUITY/TERMINALEQUITY.war" --no-check-certificate
#curl -O "https://packagerepo.prod.aws.glic.com/artifactory/glic-releases-sit/terminalequity-1.0.13/TERMINALEQUITY/TERMINALEQUITY.war" -k
echo "$TIMESTAMP: file downloaded successfully" >> $LOGFILE


if [ -d /opt/TERMINALEQUITY_Server_Setup ]; then
    cd /opt/TERMINALEQUITY_Server_Setup/TOMCAT/bin
	chmod +x /opt/TERMINALEQUITY_Server_Setup/TOMCAT/bin/startup.sh
	chmod +x /opt/TERMINALEQUITY_Server_Setup/TOMCAT/bin/shutdown.sh
	chmod +x /opt/TERMINALEQUITY_Server_Setup/TOMCAT/bin/catalina.sh
	echo "$TIMESTAMP: permission changes successfully" >> $LOGFILE
    ./shutdown.sh 
	echo "$TIMESTAMP: tomcat shutdown successfully" >> $LOGFILE
	cd /opt/TERMINALEQUITY_Server_Setup/TOMCAT/webapps
	rm -rf TERMINALEQUITY
	rm -rf TERMINALEQUITY.war
	cp -r /tmp/TERMINALEQUITY.war .
	echo "$TIMESTAMP: app deployed successfully " >> $LOGFILE
	cd /opt/TERMINALEQUITY_Server_Setup/TOMCAT/bin
	./startup.sh 
	echo "$TIMESTAMP: tomcat started successfully" >> $LOGFILE
fi











